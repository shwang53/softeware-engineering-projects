package BlackBox;

import BlackBox.Setups.SortSetup;
import org.junit.Test;

public class SortAlgorithmBlackBoxTest extends SortSetup {

    @Test
    public void dummyTest() {
        // @TODO: Delete/modify me
        int[] input = new int[] { 2, 1 };
        int[] expectedOutput = new int[] { 1, 2 };
        sortAlgorithmPUT.run(input, expectedOutput);

        // test random order
        int[] input1 = new int[] { 5, 10, 2, 1 };
        int[] expectedOutput1 = new int[] { 1, 2, 5, 10 };
        sortAlgorithmPUT.run(input1, expectedOutput1);

        // test if included negative number
        int[] input2 = new int[] { 5, -10, 2, -1 };
        int[] expectedOutput2 = new int[] { -10, -1, 2, 5 };
        sortAlgorithmPUT.run(input2, expectedOutput2);

        // test if extreme value
        int[] input3 = new int[] { 999999999, -8888888, 2, -1 };
        int[] expectedOutput3 = new int[] { -8888888, -1, 2, 999999999 };
        sortAlgorithmPUT.run(input3, expectedOutput3);

        // test if only negative values
        int[] input4 = new int[] { -3, -4, -20, -1 };
        int[] expectedOutput4 = new int[] { -20, -4, -3, -1 };
        sortAlgorithmPUT.run(input4, expectedOutput4);

        // test if only duplicated
        int[] input5 = new int[] { 1, 3, 3, 5, 3 };
        int[] expectedOutput5 = new int[] { 1, 3, 3, 3, 5 };
        sortAlgorithmPUT.run(input5, expectedOutput5);

    }

    // @TODO: Create more tests
}
