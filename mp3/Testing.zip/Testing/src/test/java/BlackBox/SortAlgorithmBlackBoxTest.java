package BlackBox;

import BlackBox.Setups.SortSetup;
import org.junit.Test;

public class SortAlgorithmBlackBoxTest extends SortSetup {

    @Test
    public void dummyTest() {
        // @TODO: Delete/modify me
        int[] input = new int[] { 2, 1 };
        int[] expectedOutput = new int[] { 1, 2 };
        sortAlgorithmPUT.run(input, expectedOutput);

        // test random order
        int[] input1 = new int[] { 5, 10, 2, 1 };
        int[] expectedOutput1 = new int[] { 1, 2, 5, 10 };
        sortAlgorithmPUT.run(input1, expectedOutput1);

        // test if included negative number
        int[] input2 = new int[] { 5, -10, 2, -1 };
        int[] expectedOutput2 = new int[] { -10, -1, 2, 5 };
        sortAlgorithmPUT.run(input2, expectedOutput2);

        // // test if included
        // int[] input3 = new int[] { 5, -10, 2, -1 };
        // int[] expectedOutput3 = new int[] { -10, -1, 2, 5 };
        // sortAlgorithmPUT.run(input3, expectedOutput3);
    }

    // @TODO: Create more tests
}
