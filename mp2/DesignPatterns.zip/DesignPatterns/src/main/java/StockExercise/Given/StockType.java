package StockExercise.Given;

//Don't modify me
public enum StockType {
    Amazon,
    Google,
}
