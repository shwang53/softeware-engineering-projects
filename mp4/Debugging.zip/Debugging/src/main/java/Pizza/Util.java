package Pizza;
/**
 * Created by Felix on 23.02.2016.
 */
public class Util {
    public static final String[] NAMES = {"Felix","Michi","Domdom","Mark","Tim","Tim","Tom","Patrick","Lenni"};
}
