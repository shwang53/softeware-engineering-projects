package Pizza;
/**
 * Created by Felix on 23.02.2016.
 */
public class Slice {

    public double calories = 0;

    public Slice(double calories){
        this.calories = calories;
    }

}
